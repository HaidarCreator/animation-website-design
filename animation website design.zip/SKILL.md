---
name: animated-landing-page
description: Build a polished, fully-animated single-file HTML landing page or marketing site using Tailwind CSS, CSS keyframes, and Intersection Observer — no external animation libraries. Use this skill ONLY when the user explicitly asks for a landing page, marketing site, hero section, or product page AND mentions animation, motion, interactive effects, or anything animated/animé. Triggers include words like "animation", "animated", "motion", "interactive", "animé", combined with "landing page", "site vitrine", "marketing page", "hero", or "product page". Do NOT use this skill for generic website requests without an animation cue, for dashboards/apps/admin UIs, or when the user only wants a static page.
---

# Animated Landing Page

Build production-quality, single-file HTML landing pages with smooth, intentional animations. The output should feel polished and modern — not gimmicky, not over-animated.

## Hard rules (never violate)

1. **Single self-contained HTML file.** All CSS in `<style>` or Tailwind via CDN, all JS inline. No external assets except Tailwind's CDN script and Google Fonts.
2. **No animation libraries.** No GSAP, Framer Motion, Anime.js, AOS, etc. Pure CSS keyframes + Tailwind transitions + Intersection Observer for scroll triggers.
3. **Dark theme by default.** Deep neutral background (e.g. `#0a0a0f`, `#08080c`, or near-black with a hint of color), high-contrast text, accent color used sparingly.
4. **Mandatory page anatomy**, in this order:
   - Navigation (sticky, with subtle backdrop-blur on scroll)
   - Hero (with the animated entrance below)
   - Features section (3–6 feature cards)
   - Social proof (testimonials, logos marquee, or stats)
   - CTA section (focused conversion block)
   - Footer
5. **Respect `prefers-reduced-motion`.** Wrap heavy animations in `@media (prefers-reduced-motion: no-preference)` or provide reduced fallbacks.
6. **Mobile-friendly.** Test layout mentally at ~380px width. Hamburger menu when nav doesn't fit.

## The animation inventory

Every page MUST include all seven of these. Do not skip any unless the user explicitly says to.

### 1. Hero entrance — fade + slide-up on load
Stagger the hero elements (eyebrow tag → headline → subhead → CTA buttons → hero visual) with ~80–120ms delays between them. Use a custom keyframe like:

```css
@keyframes heroIn {
  from { opacity: 0; transform: translateY(24px); }
  to   { opacity: 1; transform: translateY(0); }
}
.hero-in { animation: heroIn 0.8s cubic-bezier(0.22, 1, 0.36, 1) both; }
.hero-in-1 { animation-delay: 0.1s; }
.hero-in-2 { animation-delay: 0.22s; }
/* etc. */
```

### 2. Scroll-reveal on sections — Intersection Observer + Tailwind transitions
One IntersectionObserver, observe all `[data-reveal]` elements, toggle a class when in view. Use `threshold: 0.15` and `rootMargin: '0px 0px -10% 0px'` so reveals fire slightly before full visibility. Default state: `opacity-0 translate-y-6`. Revealed: `opacity-100 translate-y-0`. Transition: `transition-all duration-700 ease-out`.

```js
const io = new IntersectionObserver((entries) => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      e.target.classList.add('is-visible');
      io.unobserve(e.target);
    }
  });
}, { threshold: 0.15, rootMargin: '0px 0px -10% 0px' });
document.querySelectorAll('[data-reveal]').forEach(el => io.observe(el));
```

### 3. Hover micro-interactions on buttons/cards
- Buttons: scale (`hover:scale-[1.03]`), glow via `box-shadow` transition, gradient shift on the accent CTA.
- Cards: lift (`hover:-translate-y-1`), border-color brighten, subtle inner glow, optional gradient border on hover.
- Always `transition-all duration-300 ease-out` minimum. Use `will-change: transform` on heavily animated elements.

### 4. Animated gradient backgrounds / mesh blobs
The hero (or another hero-adjacent section) gets soft animated color blobs behind the content. Use 2–3 large, heavily blurred (`filter: blur(80px)`), low-opacity (`opacity-30` to `opacity-50`) absolutely-positioned divs with `mix-blend-mode: screen` or `multiply`, animated with a slow `blob` keyframe (translate + scale, 15–25s duration, infinite, ease-in-out).

```css
@keyframes blob {
  0%, 100% { transform: translate(0, 0) scale(1); }
  33%      { transform: translate(30px, -20px) scale(1.1); }
  66%      { transform: translate(-20px, 30px) scale(0.95); }
}
```

### 5. Marquee / infinite scroll for logos
Place in the social proof section if showing partner/client logos. Duplicate the logo set inline so the loop is seamless. Use a `marquee` keyframe translating from `0` to `-50%` over 30–40s, infinite linear. Pause on hover (`hover:[animation-play-state:paused]`).

### 6. Smooth anchor scrolling
Add `scroll-behavior: smooth` to `html`, AND offset for the sticky nav using `scroll-margin-top` on section anchors. Nav links use `href="#section-id"`.

### 7. Subtle parallax on hero
Listen to scroll and translate a hero background layer (the blobs, or a decorative element) at a fraction of scroll speed (e.g. `translateY(scrollY * 0.3)`). Use `requestAnimationFrame` and `passive: true` listener. Keep the effect subtle — max ~30% of scroll speed. Disable on mobile and when `prefers-reduced-motion` is set.

```js
const heroBg = document.querySelector('.hero-bg');
let ticking = false;
window.addEventListener('scroll', () => {
  if (!ticking && window.matchMedia('(prefers-reduced-motion: no-preference)').matches) {
    requestAnimationFrame(() => {
      heroBg.style.transform = `translateY(${window.scrollY * 0.3}px)`;
      ticking = false;
    });
    ticking = true;
  }
}, { passive: true });
```

## Style direction

- **Typography**: One sans-serif (Inter, Geist, or similar) from Google Fonts. Big, confident headlines (text-5xl to text-7xl on desktop). Tight tracking on display sizes.
- **Color**: Dark base (`#0a0a0f` family). One vibrant accent (electric blue, violet, emerald, or warm amber — pick based on the product's tone). Use it for CTAs, the hero blob, and key highlights only. Generous use of white/near-white text with reduced opacity for hierarchy (`text-white/60`, `text-white/80`).
- **Spacing**: Generous. Sections should breathe — `py-24` to `py-32` between sections on desktop.
- **Borders**: Subtle (`border-white/10` to `border-white/20`). Avoid hard divider lines.
- **Glass/glow accents**: Use sparingly on cards or the nav (`backdrop-blur-md bg-white/5 border border-white/10`).

## Workflow

1. **Identify the product/topic.** If unclear, infer something reasonable from context. Don't ask the user 5 questions — build something good and let them iterate.
2. **Pick the accent color** that fits the product (fintech → blue/violet, eco → emerald, AI/dev tools → cyan or purple, food → amber/orange).
3. **Write all section HTML first**, then layer in the animation classes/data attributes.
4. **Add the JS at the end** — Intersection Observer, parallax, and the nav scroll-state — in a single script tag.
5. **Self-review**: did you include all seven animations? Is `prefers-reduced-motion` respected? Is the page mobile-OK?

## Anti-patterns to avoid

- Loading lottie files, video backgrounds, or 3D scenes.
- Using `animate-bounce` or `animate-pulse` on hero text (looks juvenile).
- More than one accent color competing for attention.
- Animating every single element — the eye needs rest.
- Pure-black `#000` backgrounds — too harsh; use a near-black with a hint of warmth or coolness.
- Generic stock-photo placeholder images — prefer CSS-drawn shapes, gradients, or SVG illustrations.
- Forgetting the duplicated logo set in the marquee (causes a visible jump on loop).

## Output

Save the final file to `/mnt/user-data/outputs/` with a descriptive name like `landing-{product}.html`, then call `present_files` so the user can view and download it.
