# animated-landing-page

A Claude skill that builds polished, fully-animated single-file HTML landing pages — with Tailwind CSS, pure CSS keyframes, and the Intersection Observer API. No external animation libraries.

## What it does

When you ask Claude for an animated landing page, hero section, marketing site, or product page, this skill kicks in and produces a single self-contained `.html` file that includes:

- A fixed navigation bar with backdrop-blur on scroll
- An animated hero section with staggered fade-up entrance
- A features grid with hover micro-interactions
- A social-proof section (testimonials + infinite-scroll logo marquee)
- A focused CTA section
- A footer

All styled in a polished dark theme, with one accent color picked to match the product (fintech → violet/blue, AI/dev → cyan, eco → emerald, food → amber, etc.).

## The seven baked-in animations

Every page produced by this skill includes:

1. **Hero entrance** — staggered fade + slide-up on load
2. **Scroll-reveal** — Intersection Observer reveals sections as you scroll
3. **Hover micro-interactions** — buttons scale/glow, cards lift and brighten
4. **Animated gradient blobs** — soft, blurred color blobs drifting behind the hero
5. **Logo marquee** — infinite horizontal scroll, pauses on hover
6. **Smooth anchor scrolling** — with proper offset for the sticky nav
7. **Subtle parallax** — hero background drifts at ~25–30% of scroll speed

All animations respect `prefers-reduced-motion`.

## When the skill triggers

The skill activates **only** when both conditions are met:

- The user explicitly asks for a landing page, marketing site, hero section, or product page
- AND the user mentions animation, motion, interactive, or `animé`

It will **not** trigger for generic website requests, dashboards, admin UIs, or static page requests.

## Hard rules the skill enforces

- Single self-contained HTML file (no external JS/CSS except Tailwind CDN + Google Fonts)
- No animation libraries (no GSAP, Framer Motion, Anime.js, AOS, etc.)
- Dark theme by default
- Mandatory page anatomy (nav → hero → features → social proof → CTA → footer)
- `prefers-reduced-motion` respected
- Mobile-friendly layout

## Installation

### Option 1 — drop the `.skill` file into Claude

Download `animated-landing-page.skill` from the releases page and install it via the Claude UI's skill upload.

### Option 2 — clone the folder

```bash
git clone <this-repo>
```

Drop the `animated-landing-page/` folder wherever Claude reads its skills from.

## Usage

Once installed, just ask Claude something like:

> "Make me an animated landing page for a fintech app called Lumen"

> "Build an interactive marketing site for my AI dev tool"

> "Crée-moi une landing page animée pour ma plateforme de logistique"

The skill will produce a single `.html` file, save it to the outputs folder, and present it for download.

## License

Use it however you want.

## Author

Built with Claude by Faissal.
